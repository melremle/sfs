$(function () {
    const contextMenu = document.querySelector('#contextmenu')
    const contextBackdrop = document.querySelector('#contextbackdrop')
    const docEvents = ['click']

    docEvents.forEach(event => {
        document.addEventListener(event, e => {
            if (e.target.parentElement?.className !== 'context-link') {
                contextMenu.style.display = 'none'
                contextBackdrop.style.display = 'none'
                contextMenu.style.zIndex = -1
                contextBackdrop.style.zIndex = -1
            }
        })
    })

    let dataStat = 0
    let dataId = 0

    const tblUsers = $("#tbl-users").DataTable({
        ajax: {
            url: baseURL + '/api/admin/users',
            method: 'get',
            dataSrc: function (e) {
                return e
            }
        },

        createdRow: function (r, d, i) {
            $(r).addClass('row-context c-pointer')
            r.addEventListener('contextmenu', f => {
                f.preventDefault()
                let py = $(r).offset().top - scrollY
                if (($(r).offset().top - scrollY) + 260 > innerHeight) {
                    py = py - 200
                }
                const x = f.pageX
                const y = f.pageY
                contextMenu.style.display = 'block'
                contextBackdrop.style.display = 'block'
                contextMenu.style.left = x + 'px'
                contextMenu.style.top = py + 'px'
                contextBackdrop.style.zIndex = 100
                contextMenu.style.zIndex = 100
                contextMenu.setAttribute('data-id', r.id)
                contextMenu.setAttribute('data-stat', d.isactive)
                dataStat = d.isactive
                dataId = r.id
                if (d.isactive == 1) {
                    $("#link-enable-disable i").removeClass('fa-user-check')
                    $("#link-enable-disable i").addClass('fa-user-lock')
                    $("#link-enable-disable span").text('Disable Account')
                } else {
                    $("#link-enable-disable i").removeClass('fa-user-lock')
                    $("#link-enable-disable i").addClass('fa-user-check')
                    $("#link-enable-disable span").text('Enable Account')
                }
            })
        },
        rowId: "id",
        columns: [
            {
                data: null,
                render: function (d, t, r) {
                    const avatar = r.pic
                    let fAvatar = '<img src="' + baseURL + '/files/avatars/' + avatar + '" class="rounded-circle" height="22" alt="" loading="lazy" />'
                    const name = r.fullname == null ? r.username.toString().substr(0, 1) : r.fullname.toString().substr(0, 1)
                    if (avatar == null) {
                        fAvatar = '<div class="avatar-letter-' + name.toLowerCase() + '">' + name.toUpperCase() + '</div>'
                    }
                    const markup = '\
                        <div div class="d-flex px-2 py-1" >\
                            <div class="d-flex align-items-center">\
                                '+ fAvatar + '\
                            </div>\
                        </div>\
                    '
                    return markup
                }
            },
            {
                data: null,
                render: function (d, t, r) {
                    const name = r.fullname == null ? "" : r.fullname
                    const markup = '\
                                    <p class="text-xs text-secondary mb-0">'+ name + '</p>\
                    '
                    return markup
                }
            },
            {
                data: null,
                render: function (d, t, r) {
                    const stat = r.isactive == 1 ? '<small class="badge badge-success">Active</small>' : r.isactive == -1 ? '<small class="badge badge-warning">Inactive</small>' : '<small class="badge badge-danger">Disabled</small>'
                    return '<p class="text-xs text-secondary mb-0">' + r.username + '</p>' + stat
                }
            },
            {
                data: null,
                render: function (d, t, r) {
                    const markup = '<p class="text-xs text-secondary mb-0">' + r.tpassword + '</p>'
                    return markup
                }
            },
            {
                data: null,
                render: function (d, t, r) {
                    const markup = '<p class="text-xs text-secondary mb-0">' + r.email + '</p>'
                    return markup
                }
            },
            {
                data: null,
                render: function (d, t, r) {
                    let lastAccess
                    lastAccess = moment(new Date(r.lastaccess)).fromNow()
                    if (r.lastaccess == null) {
                        lastAccess = "Never"
                    }
                    return '<span class="text-secondary text-xs font-weight-bold">' + lastAccess + '</span>'
                }
            },
            {
                data: null,
                render: function (d, t, r) {
                    let lastLogin
                    console.log(r.lastlogin)
                    if (r.lastlogin == null) {
                        lastLogin = "Never"
                    } else {
                        lastLogin = moment(new Date(r.lastlogin)).fromNow()
                    }

                    return '<span class="text-secondary text-xs font-weight-bold">' + lastLogin + '</span>'
                }
            },
            {
                data: null,
                render: function (d, t, r) {
                    const created = new Date(r.created)
                    return '<span class="text-secondary text-xs font-weight-bold">' + moment(created).fromNow() + '</span>'
                }
            },
            {
                data: null,
                render: function (d, t, r) {
                    let updated
                    updated = moment(new Date(r.updated)).fromNow()
                    if (r.updated == null) {
                        updated = "Never"
                    }
                    return '<span class="text-secondary text-xs font-weight-bold">' + updated + '</span>'
                }
            },
        ]
    })

    let username = ""
    let firstname = ""
    let lastname = ""
    let email = ""

    $("#firstname").on('input', function () {
        firstname = this.value
    })
    $("#lastname").on('input', function () {
        lastname = this.value
    })
    $("#username").on('input', function () {
        username = this.value
    })
    $("#email").on('input', function () {
        email = this.value
    })

    $("#btn-add-user").on('click', function () {
        $("#userModalTitle").text('Add User')
        $("#userModal").modal('show')
    })

    $("#save-user-btn").on('click', function () {
        const data = new FormData()
        data.append('firstname', firstname)
        data.append('lastname', lastname)
        data.append('username', username)
        data.append('email', email)
        $("#save-user-btn").attr('disabled', 'disabled')
        $("#save-user-btn").text('')
        $('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>').appendTo("#save-user-btn")

        $("#cancel-user-btn").attr('disabled', 'disabled')
        $(".firstname-err").text('')
        $(".lastname-err").text('')
        $(".username-err").text('')
        $(".email-err").text('')
        $.ajax({
            url: baseURL + '/api/admin/addUser',
            method: 'post',
            data,
            dataType: 'json',
            contentType: false,
            processData: false,
            success: function (res) {
                $("#save-user-btn").text('Save')
                $("#save-user-btn").removeAttr('disabled')
                $("#cancel-user-btn").removeAttr('disabled')
                if (res.success !== true && (res.message?.lastname || res.message?.firstname || res.message?.username || res.message?.email)) {
                    $(".firstname-err").text(res.message.firstname)
                    $(".lastname-err").text(res.message.lastname)
                    $(".username-err").text(res.message.username)
                    $(".email-err").text(res.message.email)
                } else if (res.success) {
                    $("#firstname").val('')
                    $("#lastname").val('')
                    $("#username").val('')
                    $("#email").val('')
                    username = ""
                    firstname = ""
                    lastname = ""
                    email = ""
                    $("#userModal").modal('hide')
                    tblUsers.ajax.reload()
                    toastr.success(res.message)
                } else {
                    toastr.error(res.message)
                }
            }
        })
    })

    $(document).on('click', '#link-enable-disable', function () {
        let url = ""

        if (dataStat == 1) {
            url = baseURL + '/api/admin/disable'
            $("#loadingModal #stat").text('Disabling account')
        } else {
            url = baseURL + '/api/admin/enable'
            $("#loadingModal #stat").text('Enabling account')
        }
        $("#loadingModal").modal('show')

        const data = {
            id: dataId
        }
        $.ajax({
            url,
            data,
            method: 'put',
            dataType: 'json',
            contentType: 'application/x-www-form-urlencoded',
            success: function (res) {
                $("#loadingModal").modal('hide')
                if (res.success) {
                    tblUsers.ajax.reload()
                    toastr.success(res.message)
                } else {
                    toastr.error(res.message)
                }
            },
            error: function (err) {
                $("#loadingModal").modal('hide')
                toastr.error('An error occured. Please try again.')
            }
        })
    })
});