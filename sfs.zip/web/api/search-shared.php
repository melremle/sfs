<?php

require_once dirname(__DIR__, 2) . '/functions/Both/Search.php';

$search = new Search;
$search->searchShared();
