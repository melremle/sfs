<?php

require_once dirname(__DIR__, 3) . '/functions/Shared.php';
$mydrive = new Shared;
$mydrive->getSharedWithMe();
