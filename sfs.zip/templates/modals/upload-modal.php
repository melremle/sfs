<?php
$mediaTypesAllowed = "";
foreach (json_decode($_SESSION['allowed-media-types'], true) as $mediatype) {
    $mediaTypesAllowed .= $mediatype['ext'] . ',';
}
$mediaTypesAllowed = substr($mediaTypesAllowed, 0, strlen($mediaTypesAllowed) - 1);
?>
<form id="frm-upload" action="<?= APP_URL ?>/api/file/upload" method="POST" enctype="multipart/form-data" style="display: none;">
    <input type="file" id="u-file" readonly accept="<?= $mediaTypesAllowed ?>"/>
</form>