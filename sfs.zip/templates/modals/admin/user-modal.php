<div class="modal fade" id="userModal" data-mdb-keyboard="false" data-mdb-backdrop="static" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="userModalTitle">Add User Account</h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-6 mb-3">
                        <div class="form-outline">
                            <input type="text" id="firstname" class="form-control" value="" />
                            <label class="form-label" for="username">First Name</label>
                        </div>
                        <small class="mb-2 text-danger firstname-err"></small>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="form-outline">
                            <input type="text" id="lastname" class="form-control" value="" />
                            <label class="form-label" for="username">Last Name</label>
                        </div>
                        <small class="mb-2 text-danger lastname-err"></small>
                    </div>
                    <div class="col-5 mb-3">
                        <div class="form-outline">
                            <input type="text" id="username" class="form-control" value="" />
                            <label class="form-label" for="username">Username</label>
                        </div>
                        <small class="mb-2 text-danger username-err"></small>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="form-outline">
                            <input type="email" id="email" class="form-control" value="" />
                            <label class="form-label" for="username">Email</label>
                        </div>
                        <small class="mb-2 text-danger email-err"></small>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button id="save-user-btn" class="btn btn-success">Save</button>
                <button id="cancel-user-btn" class="btn btn-danger ripple" data-mdb-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>