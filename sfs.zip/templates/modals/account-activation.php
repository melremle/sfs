<div class="modal fade" id="activationModal" data-mdb-keyboard="false" data-mdb-backdrop="static" tabindex="-1" aria-labelledby="activationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
            </div>
            <div class="modal-footer">
                <button id="continue-btn" class="btn btn-primary">Continue</button>
            </div>
        </div>
    </div>
</div>