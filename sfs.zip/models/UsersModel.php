<?php

require_once dirname(__DIR__) . '/config/database.php';

class UsersModel extends DB
{
    public $ID;
    public $Username;
    public $Email;
    public $Password;
    public $TemporaryPassword;
    public $FirstName;
    public $LastName;
    public $Pic;
    public $IsActive;
    public $Access;
    public $LastAccess;
    public $LastLogin;
    public $CreatedOn;
    public $UpdatedOn;

    public function __construct(
        $ID = '',
        $Username = '',
        $Email = '',
        $Password = '',
        $TemporaryPassword = '',
        $FirstName = '',
        $LastName = '',
        $Pic = '',
        $IsActive = '',
        $Access = '',
        $LastAccess = '',
        $LastLogin = '',
        $CreatedOn = '',
        $UpdatedOn = ''
    ) {
        $this->ID = $ID;
        $this->Username = $Username;
        $this->Email = $Email;
        $this->Password = $Password;
        $this->TemporaryPassword = $TemporaryPassword;
        $this->FirstName = $FirstName;
        $this->LastName = $LastName;
        $this->Pic =   $Pic;
        $this->IsActive =   $IsActive;
        $this->Access =   $Access;
        $this->LastAccess =   $LastAccess;
        $this->LastLogin =   $LastLogin;
        $this->CreatedOn = $CreatedOn;
        $this->UpdatedOn = $UpdatedOn;
    }

    public function checkUsername()
    {
        try {
            $con = $this->con();
            $query = "SELECT ID FROM users WHERE Username = :username";
            $sql = $con->prepare($query);
            $params = array(
                $this->Username,
            );
            if ($sql->execute($params)) {
                return $sql->rowCount();
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function checkFullname()
    {
        try {
            $con = $this->con();
            $query = "SELECT ID FROM users WHERE FirstName = :firstname AND LastName = :lastname";
            $sql = $con->prepare($query);
            $params = array(
                ':firstname' => $this->FirstName,
                ':lastname' => $this->LastName,
            );
            if ($sql->execute($params)) {
                return $sql->rowCount();
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function checkEmail()
    {
        try {
            $con = $this->con();
            $query = "SELECT ID FROM users WHERE Email = :email ";
            $sql = $con->prepare($query);
            $params = array(
                ':email' => $this->Email
            );
            if ($sql->execute($params)) {
                return $sql->rowCount();
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function checkPassword()
    {
        try {
            $con = $this->con();
            $query = "SELECT ID, Username, Access, CONCAT(FirstName, ' ', LastName) as fullname, Pic, IsActive FROM users WHERE Username = :username AND Password = :password";
            $sql = $con->prepare($query);
            $params = array(
                $this->Username,
                $this->Password,
            );
            if ($sql->execute($params)) {
                return $sql->fetch();
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }



    public function getAllUsers()
    {
        try {
            $con = $this->con();
            $query = "SELECT ID as id, Username as username, CONCAT(FirstName, ' ', LastName) as fullname, Pic as pic, TemporaryPassword as tpassword, Email as email, LastAccess as lastaccess, LastLogin as lastlogin, CreatedOn as created, UpdatedOn as updated, IsActive as isactive FROM users WHERE Access != 1";
            $sql = $con->prepare($query);
            if ($sql->execute()) {
                return $sql->fetchAll();
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function getAllUsersPerTerm($fileID, $uid)
    {
        try {
            $con = $this->con();
            $query = "SELECT users.ID as id, CONCAT(FirstName, ' ', LastName) as fullname, Pic as pic, Email as email, Username as username FROM users WHERE users.ID NOT IN (SELECT UserID FROM shared_files WHERE FileID = :fid) AND users.ID != :uid AND (Access != 1 AND IsActive = 1) AND (FirstName LIKE :firstname OR LastName LIKE :lastname OR Email LIKE :email)";
            $params = array(
                ':firstname' => '%' . $this->FirstName . '%',
                ':lastname' => '%' . $this->LastName . '%',
                ':email' => '%' . $this->Email . '%',
                ':fid' => $fileID,
                ':uid' => $uid,
            );
            $sql = $con->prepare($query);
            if ($sql->execute($params)) {
                return $sql->fetchAll();
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function getAllUsersShared($fileID)
    {
        try {
            $con = $this->con();
            $query = "SELECT shared_files.ID as id, CONCAT(FirstName, ' ', LastName) as fullname, Pic as pic, Email as email, Username as username FROM users INNER JOIN shared_files ON shared_files.UserID = users.ID WHERE shared_files.FileID = :fid AND (Access != 1 AND IsActive = 1)";
            $params = array(
                ':fid' => $fileID,
            );
            $sql = $con->prepare($query);
            if ($sql->execute($params)) {
                return $sql->fetchAll();
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function addUser()
    {
        try {
            $con = $this->con();
            $query = "
                INSERT INTO
                    users
                (
                    Username,
                    Email,
                    TemporaryPassword,
                    FirstName,
                    LastName,
                    CreatedOn
                )
                VALUES
                (
                    :username,
                    :email,
                    :tpassword,
                    :fname,
                    :lname,
                    :date
                )
            ";
            $params = array(
                ':username' => $this->Username,
                ':email' => $this->Email,
                ':tpassword' => $this->TemporaryPassword,
                ':fname' => $this->FirstName,
                ':lname' => $this->LastName,
                ':date' => date('Y-m-d H:i:s')
            );
            $sql = $con->prepare($query);
            if ($sql->execute($params)) {
                return true;
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function updatePassword()
    {
        try {
            $con = $this->con();
            $query = "
                UPDATE
                    users
                SET
                    TemporaryPassword = '',
                    IsActive = 1,
                    Password = :password,
                    UpdatedOn = :date
                WHERE
                    Username = :username
            ";
            $params = array(
                ':username' => $this->Username,
                ':password' => $this->Password,
                ':date' => date('Y-m-d H:i:s')
            );
            $sql = $con->prepare($query);
            if ($sql->execute($params)) {
                return true;
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }


    public function disableAccount()
    {
        try {
            $con = $this->con();
            $query = "
                UPDATE
                    users
                SET
                    IsActive = 0,
                    UpdatedOn = :date
                WHERE
                    ID = :id
            ";
            $params = array(
                ':id' => $this->ID,
                ':date' => date('Y-m-d H:i:s')
            );
            $sql = $con->prepare($query);
            if ($sql->execute($params)) {
                return true;
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function enableAccount()
    {
        try {
            $con = $this->con();
            $query = "
                UPDATE
                    users
                SET
                    IsActive = 1,
                    UpdatedOn = :date
                WHERE
                    ID = :id
            ";
            $params = array(
                ':id' => $this->ID,
                ':date' => date('Y-m-d H:i:s')
            );
            $sql = $con->prepare($query);
            if ($sql->execute($params)) {
                return true;
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function getFullname()
    {
        try {
            $con = $this->con();
            $query = "
                SELECT
                    CONCAT(FirstName, ' ', LastName) as fullname
                FROM
                    users
                WHERE
                    ID = :id
            ";
            $params = array(
                ':id' => $this->ID,
            );
            $sql = $con->prepare($query);
            if ($sql->execute($params)) {
                return $sql->fetch();
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function getEmail()
    {
        try {
            $con = $this->con();
            $query = "
                SELECT
                    Email
                FROM
                    users
                WHERE
                    ID = :id
            ";
            $params = array(
                ':id' => $this->ID,
            );
            $sql = $con->prepare($query);
            if ($sql->execute($params)) {
                return $sql->fetch();
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function checkIfInactive()
    {
        try {
            $con = $this->con();
            $query = "
                SELECT
                    ID
                FROM
                    users
                WHERE
                    ID = :id AND
                    IsActive = -1
            ";
            $params = array(
                ':id' => $this->ID,
            );
            $sql = $con->prepare($query);
            if ($sql->execute($params)) {
                return $sql->rowCount() > 0;
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }


    public function updateLastAccess()
    {
        try {
            $con = $this->con();
            $query = "UPDATE users SET LastAccess = :date WHERE ID = :id";
            $sql = $con->prepare($query);
            $params = array(
                ':id' => $this->ID,
                ':date' => date('Y-m-d H:i:s'),
            );
            if ($sql->execute($params)) {
                return true;
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }

    public function updateLastLogin()
    {
        try {
            $con = $this->con();
            $query = "UPDATE users SET LastLogin = :date WHERE ID = :id";
            $sql = $con->prepare($query);
            $params = array(
                ':id' => $this->ID,
                ':date' => date('Y-m-d H:i:s'),
            );
            if ($sql->execute($params)) {
                return true;
            }
            return json_encode($sql->errorInfo());
        } catch (PDOException $e) {
            http_response_code(500);
            return (json_encode($e->getMessage()));
        }
    }
}
